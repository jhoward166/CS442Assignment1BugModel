package bugModel.results;

public interface Display {
    // add appropriate method
    public void writeToScreen();
} 
