package bugModel.results;

public interface StoreMovements {
    public void addCommand(String command);
}

