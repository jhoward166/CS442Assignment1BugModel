package bugModel.results;

public interface FileLog {
    // add appropriate method 
    public void writeToFile(String fileIn);
} 
